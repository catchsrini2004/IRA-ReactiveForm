import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-benefiriaries',
  templateUrl: './benefiriaries.component.html',
  styleUrls: ['./benefiriaries.component.css']
})
export class BenefiriariesComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  closeflag = true;
  rightflag = [];
  addrow: FormArray;
  arrList = [];
  allTotal = 0;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
        itemsList : this.formBuilder.array([this.createObj()])
         
      });
  }

  getControls() {
    return (this.registerForm.get('itemsList')as FormArray).controls;
  }

  // convenience getter for easy access to form fields
  get f() { return ( this.registerForm.get('itemsList')as FormArray).controls; }


  createObj() {
    this.rightflag.push(false)
   return  this.formBuilder.group({
      fullname: ['', Validators.required],
      dob: ['', Validators.required],
      ssn: [''],          
      relationShip: ['', [Validators.required, ]],
      percent: ['', [Validators.required]],
      close: [''],
      right: ['']
      
    });
  
  }

  onSubmit() {
      this.submitted = true;

      // stop here if form is invalid
      if (this.registerForm.invalid) {
          return;
      }

      alert('SUCCESS!! :-)')
  }

  checkData(event = '', i) { debugger;

    var total = 0;

    for(let obj of this.registerForm.value.itemsList)
    {
      total = total + obj.percent;
    }
    if (total < 100) {
      this.rightflag[i]= true;
    }
    else {
      this.rightflag[i]= false;
    }
    this.allTotal = total;

  }

  remoeRow(i) :void {
    
    this.addrow =this.registerForm.get('itemsList') as FormArray;
    if (this.addrow.length > 1) {
   
    this.addrow.removeAt(this.addrow.length-1);
    this.checkData('', i-1)
  
    }
    

  }

  addnewRow(): void {
    this.addrow =this.registerForm.get('itemsList') as FormArray;
    this.addrow.push(this.createObj())
    this.rightflag.push(false)
    
  }
}
