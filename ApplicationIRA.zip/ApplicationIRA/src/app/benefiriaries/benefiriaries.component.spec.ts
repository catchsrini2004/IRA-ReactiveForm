import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BenefiriariesComponent } from './benefiriaries.component';

describe('BenefiriariesComponent', () => {
  let component: BenefiriariesComponent;
  let fixture: ComponentFixture<BenefiriariesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BenefiriariesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BenefiriariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
